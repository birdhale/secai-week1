#!/bin/zsh
HACKER="CyberSmith"
MISSION="Infiltrate Mainframe"
echo "Operative: $HACKER"
echo "Objective: $MISSION"

