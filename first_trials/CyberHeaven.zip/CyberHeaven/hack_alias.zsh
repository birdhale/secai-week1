#!/bin/zsh
ALIAS="Esmerald"
echo "Access granted to $ALIAS. Ready to dominate the Shell Matrix!"

