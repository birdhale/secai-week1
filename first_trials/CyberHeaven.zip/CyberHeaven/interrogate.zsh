#!/bin/zsh
echo "State your codename:"
read codename
echo "Welcome, $codename. Accessing secure protocols..."

read -p "Enter target system name: " target
echo "Target acquired: $target. Initiating scan."

