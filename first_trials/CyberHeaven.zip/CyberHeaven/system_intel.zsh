 #!/bin/zsh
HOST=$(hostname)
USER=$(whoami)
echo "Intel: Running on $HOST as $USER."

